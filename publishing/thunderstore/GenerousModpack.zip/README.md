Hello!
This mod was made primarily to play with my frtiends, but anyone can enjoy it.

Version: 1.5.0

So far, 11 cards have been added. At the moment, 4 more are being developed.